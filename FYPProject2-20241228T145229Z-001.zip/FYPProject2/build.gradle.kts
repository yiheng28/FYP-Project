buildscript {
    dependencies {
        classpath("com.android.tools.build:gradle:8.2.1")
        classpath("com.google.gms:google-services:4.4.2")
    }
}

// Plugin block
plugins {
    id("com.android.application") version "8.2.1" apply false
}

tasks.register<Delete>("clean") {
    delete(rootProject.buildDir)
}
